export class Transaction{
    transactionId!: number;
    transactionAmount!: number;
    transactionDateTime!: Date;
    transactionType!: string;
    account: any;
}