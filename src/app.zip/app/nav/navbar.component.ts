import { Component, OnInit } from "@angular/core";

@Component({
    selector: 'nav-bar',
    templateUrl: './navbar.component.html',
    styles: [`
    .nav.navbar-nav {font-size: 15px;}
    `]
})

export class NavbarComponent implements OnInit{
    user : any;

    ngOnInit(): void {
        if(localStorage.getItem('user') != null){
            this.user = JSON.parse(localStorage.getItem('user') || '{}');
        }
    }
}
