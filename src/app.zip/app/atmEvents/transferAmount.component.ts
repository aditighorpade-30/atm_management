import { Component, OnInit } from "@angular/core";
import { Route, Router } from "@angular/router";
import { AtmService } from "../atm.service";
import { Transfer } from "../transfer";

@Component({
    templateUrl: './transferAmount.component.html'
})
export class TransferAmountComponent implements OnInit{
    transfer: Transfer = new Transfer();
    transfers: Transfer[] = []
     
    constructor(
        private atmService: AtmService,
        private router: Router
        ){}
    ngOnInit(): void {
        
    }

    onSubmit(){
        this.transfer;
        let transfer = {
            senderAccNo: this.transfer.senderAccNo,
            receiverAccNo: this.transfer.receiverAccNo,
            amount: this.transfer.amount
        }
        // this.atmService.getTransferAmount(data2)
        this.atmService.getTransferAmount(transfer).subscribe(data => {
            console.log(data);
            alert('Amount Transfered successfully');
            this.router.navigate(['/atmEvents'])
        }); 
    }

}