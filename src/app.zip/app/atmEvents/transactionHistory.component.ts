import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AtmService } from "../atm.service";
import { Transaction } from "../transaction";

@Component({
    templateUrl: './transactionHistory.component.html'
})
export class TransactionHistoryComponent implements OnInit{
    transactions:Transaction[] = []

    constructor(private atmService: AtmService, private router: Router){}

    ngOnInit(): void {
        this.getTransactions();
    }

    private getTransactions(){
        this.atmService.getTransactionsList().subscribe(data => {
            this.transactions = data;
            // console.log(this.transactions);
            
        });
    }
}