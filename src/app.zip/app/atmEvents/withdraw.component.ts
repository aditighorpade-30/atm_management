import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AtmService } from "../atm.service";
import { Withdraw } from "../withdraw";

@Component({
    templateUrl: './withdraw.component.html'
})
export class WithdrawComponent implements OnInit{
    withdraw: Withdraw = new Withdraw();
    constructor(private atmService: AtmService, private router: Router){}

    ngOnInit(){

    }

    onSubmit(){
        this.withdraw;
        let withdraw = {
            accNo: this.withdraw.accNo,
            amount: this.withdraw.amount
        }
        // this.atmService.getTransferAmount(data2)
        this.atmService.getWithdrawAmount(withdraw).subscribe(data => {
            console.log(data);
            alert('Amount Withdraw successfully');
            this.router.navigate(['/atmEvents'])
        }); 
    }


}