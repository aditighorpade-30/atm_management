import { Component, OnInit } from "@angular/core";
import { ToastrService } from "../common/toastr.service";

declare let toastr: any

@Component({
    templateUrl: './atmEvents-list.component.html',
    styles: [`
        .btn-info {
            min-width: 160px;
            max-width: 160px;
        }
        .btn-primary {
            min-width: 160px;
            max-width: 160px;
        }
    `]
    
})

export class AtmEventsListComponent{

    constructor( private toastr: ToastrService ){
        
    }

    transactionId!: number;
}