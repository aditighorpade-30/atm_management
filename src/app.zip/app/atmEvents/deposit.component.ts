import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { AtmService } from "../atm.service";
import { Deposit } from "../deposit";

@Component({
    templateUrl: './deposit.component.html'
})
export class DepositComponent implements OnInit{
    deposit: Deposit = new Deposit;
    constructor(private atmService: AtmService, private router: Router){}
    ngOnInit(){

    }
    
    onSubmit(){
        this.deposit;
        let deposit = {
            accNo: this.deposit.accNo,
            amount: this.deposit.amount
        }
        // this.atmService.getTransferAmount(data2)
        this.atmService.getDepositAmount(deposit).subscribe(data => {
            console.log(data);
            alert('Amount Deposit successfully');
            this.router.navigate(['/atmEvents'])
        });   
    }

}