export class Transfer{
    senderAccNo!: number;
    receiverAccNo!: number;
    amount!: any;
}