export class Deposit {
    accNo!: number;
    amount!: number;
}