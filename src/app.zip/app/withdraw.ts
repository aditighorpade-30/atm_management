export class Withdraw {
    accNo!: number;
    amount!: number;
}